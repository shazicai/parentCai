package com.spc.springweb.jframe.moyu;


import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author caiJH
 * @Date 2026/1/14 2:50 PM
 * @Version 1.0
 */
public class MultiCountdownTimer extends JFrame {

    // 组件声明
    private JTable timerTable;
    private DefaultTableModel tableModel;
    private JButton addButton;
    private JButton startButton;
    private JButton pauseButton;
    private JButton resetButton;
    private JButton removeButton;
    private JTextField nameField;
    private JSpinner hourSpinner;
    private JSpinner minuteSpinner;
    private JSpinner secondSpinner;
    private JLabel activeLabel;

    // 数据模型
    private List<TimerTask> timerTasks;
    private Timer updateTimer;

    // 表头
    private final String[] COLUMN_NAMES = {"任务名称", "总时间", "剩余时间", "状态"};

    public MultiCountdownTimer() {
        setTitle("多任务倒计时管理器");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        timerTasks = new ArrayList<>();
        initComponents();
        setupUpdateTimer();

        setVisible(true);
        addTask();
    }

    // 添加任务逻辑
    private static List<TimerTaskDate> timerTaskDates = new ArrayList<>();
    private static List<String> timerTaskNames = new ArrayList<>();
    static {
        timerTaskDates.add(new TimerTaskDate("36级别BOSS", 0, 0, 10,null));
        timerTaskDates.add(new TimerTaskDate("37级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("38级别BOSS", 0, 20, 0,"精品"));
        timerTaskNames.add("38级别BOSS");
        timerTaskDates.add(new TimerTaskDate("41级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("42级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("43级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("46级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("47级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("48级别BOSS", 0, 20, 0,"精品"));
        timerTaskNames.add("48级别BOSS");
        timerTaskDates.add(new TimerTaskDate("51级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("52级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("53级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("54级别BOSS", 0, 20, 0,null));
        timerTaskDates.add(new TimerTaskDate("55级别BOSS", 0, 20, 0,"精品"));
        timerTaskNames.add("55级别BOSS");
    }
    private static class TimerTaskDate {
        private String name;
        private int hours;
        private int minutes;
        private int seconds;
        // 表示超级
        private String colorMark;

        public TimerTaskDate(String name, int hours, int minutes, int seconds, String color) {
            this.name = name;
            this.hours = hours;
            this.minutes = minutes;
            this.seconds = seconds;
            this.colorMark = color;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getHours() {
            return hours;
        }

        public void setHours(int hours) {
            this.hours = hours;
        }

        public int getMinutes() {
            return minutes;
        }

        public void setMinutes(int minutes) {
            this.minutes = minutes;
        }

        public int getSeconds() {
            return seconds;
        }

        public void setSeconds(int seconds) {
            this.seconds = seconds;
        }

        public String getColorMark() {
            return colorMark;
        }

        public void setColorMark(String colorMark) {
            this.colorMark = colorMark;
        }
    }
    private void addTask(){
        // 添加任务
        timerTaskDates.forEach(timerTaskDate -> {
            addTimerTask(2, timerTaskDate.getName(), timerTaskDate.getHours(), timerTaskDate.getMinutes(), timerTaskDate.getSeconds(), timerTaskDate.getColorMark());
        });
    }


    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // 顶部面板 - 添加新任务
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        topPanel.setBorder(BorderFactory.createTitledBorder("添加新任务"));

        topPanel.add(new JLabel("任务名称:"));
        nameField = new JTextField("任务1", 15);
        topPanel.add(nameField);

        topPanel.add(new JLabel("时:"));
        hourSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 23, 1));
        hourSpinner.setPreferredSize(new Dimension(60, 25));
        topPanel.add(hourSpinner);

        topPanel.add(new JLabel("分:"));
        minuteSpinner = new JSpinner(new SpinnerNumberModel(5, 0, 59, 1));
        minuteSpinner.setPreferredSize(new Dimension(60, 25));
        topPanel.add(minuteSpinner);

        topPanel.add(new JLabel("秒:"));
        secondSpinner = new JSpinner(new SpinnerNumberModel(0, 0, 59, 1));
        secondSpinner.setPreferredSize(new Dimension(60, 25));
        topPanel.add(secondSpinner);

        addButton = new JButton("添加任务");
        addButton.setBackground(new Color(70, 130, 180));
        addButton.setForeground(Color.black);
        topPanel.add(addButton);

        add(topPanel, BorderLayout.NORTH);

        // 中央面板 - 任务表格
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 表格不可编辑
            }
        };

        timerTable = new JTable(tableModel);
        timerTable.setRowHeight(30);
        timerTable.getTableHeader().setFont(new Font("微软雅黑", Font.BOLD, 12));
        timerTable.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        timerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // 设置列宽
        timerTable.getColumnModel().getColumn(0).setPreferredWidth(150);
        timerTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        timerTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        timerTable.getColumnModel().getColumn(3).setPreferredWidth(100);

        // 设置表格渲染器，根据状态改变颜色
        timerTable.setDefaultRenderer(Object.class, new TimerTableCellRenderer());

        JScrollPane scrollPane = new JScrollPane(timerTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("倒计时任务列表"));
        add(scrollPane, BorderLayout.CENTER);

        // 底部面板 - 控制按钮
        JPanel bottomPanel = new JPanel(new BorderLayout());

        // 左下方 - 活动任务计数
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        activeLabel = new JLabel("活动任务: 0 个");
        activeLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        infoPanel.add(activeLabel);
        bottomPanel.add(infoPanel, BorderLayout.WEST);

        // 右下方 - 控制按钮
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        startButton = new JButton("开始选中");
        startButton.setBackground(new Color(34, 139, 34));
        startButton.setForeground(Color.black);
        controlPanel.add(startButton);

        pauseButton = new JButton("暂停选中");
        pauseButton.setBackground(new Color(218, 165, 32));
        pauseButton.setForeground(Color.black);
        controlPanel.add(pauseButton);

        resetButton = new JButton("重置选中");
        resetButton.setBackground(new Color(70, 130, 180));
        resetButton.setForeground(Color.black);
        controlPanel.add(resetButton);

        removeButton = new JButton("删除选中");
        removeButton.setBackground(new Color(178, 34, 34));
        removeButton.setForeground(Color.black);
        controlPanel.add(removeButton);

        JButton startAllButton = new JButton("全部开始");
        startAllButton.setBackground(new Color(34, 139, 34));
        startAllButton.setForeground(Color.black);
        controlPanel.add(startAllButton);

        JButton resetAllButton = new JButton("全部重置");
        resetAllButton.setBackground(new Color(70, 130, 180));
        resetAllButton.setForeground(Color.black);
        controlPanel.add(resetAllButton);

        bottomPanel.add(controlPanel, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);

        // 添加事件监听器
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addTimerTask(1,null,0, 0, 0,null);
            }
        });

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startSelectedTask();
            }
        });

        pauseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pauseSelectedTask();
            }
        });

        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetSelectedTask();
            }
        });

        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedTask();
            }
        });

        startAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startAllTasks();
            }
        });

        resetAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetAllTasks();
            }
        });
    }

    private void setupUpdateTimer() {
        updateTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateAllTimers();
            }
        });
        updateTimer.start();
    }

    private void addTimerTask(Integer type, String _name, int _hours, int _minutes, int _seconds, String _colorMark) {
        String name = "";
        int hours, minutes, seconds;
        String colorMark;

        if(type == 1){
            name = nameField.getText().trim();
            hours = (int) hourSpinner.getValue();
            minutes = (int) minuteSpinner.getValue();
            seconds = (int) secondSpinner.getValue();
            colorMark = _colorMark;
        }else {
            name = _name;
            hours = _hours;
            minutes = _minutes;
            seconds = _seconds;
            colorMark = _colorMark;
        }
        if (name.isEmpty()) {
            name = "未命名任务";
        }

        int totalSeconds = hours * 3600 + minutes * 60 + seconds;

        if (totalSeconds <= 0) {
            JOptionPane.showMessageDialog(this,
                    "总时间必须大于0秒！",
                    "输入错误",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        TimerTask task = new TimerTask(name, totalSeconds, colorMark);
        timerTasks.add(task);

        // 添加到表格
        Object[] rowData = {
                task.getName(),
                formatTime(task.getTotalSeconds()),
                formatTime(task.getRemainingSeconds()),
                task.getStatus()
        };
        tableModel.addRow(rowData);

        // 更新活动任务计数
        updateActiveCount();

        // 清除输入框
        nameField.setText("任务" + (timerTasks.size() + 1));
    }

    private void startSelectedTask() {
        int selectedRow = timerTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < timerTasks.size()) {
            TimerTask task = timerTasks.get(selectedRow);
            if (!task.isRunning()) {
                task.start();
                updateTableRow(selectedRow);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    "请先选择一个任务！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void pauseSelectedTask() {
        int selectedRow = timerTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < timerTasks.size()) {
            TimerTask task = timerTasks.get(selectedRow);
            if (task.isRunning()) {
                task.pause();
                updateTableRow(selectedRow);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    "请先选择一个任务！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void resetSelectedTask() {
        int selectedRow = timerTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < timerTasks.size()) {
            TimerTask task = timerTasks.get(selectedRow);
            task.reset();
            updateTableRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(this,
                    "请先选择一个任务！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void removeSelectedTask() {
        int selectedRow = timerTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < timerTasks.size()) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "确定要删除选中的任务吗？",
                    "确认删除",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                timerTasks.remove(selectedRow);
                tableModel.removeRow(selectedRow);
                updateActiveCount();
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    "请先选择一个任务！",
                    "提示",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void startAllTasks() {
        for (int i = 0; i < timerTasks.size(); i++) {
            TimerTask task = timerTasks.get(i);
            if (!task.isRunning() && task.getRemainingSeconds() > 0) {
                task.start();
                updateTableRow(i);
            }
        }
        updateActiveCount();
    }

    private void resetAllTasks() {
        for (int i = 0; i < timerTasks.size(); i++) {
            TimerTask task = timerTasks.get(i);
            task.reset();
            updateTableRow(i);
        }
        updateActiveCount();
    }

    private void updateAllTimers() {
        for (int i = 0; i < timerTasks.size(); i++) {
            System.out.println("-------3333");
            TimerTask task = timerTasks.get(i);
            if (task.isRunning()) {
                boolean finished = task.update();
                updateTableRow(i);

                if (finished) {
                    // 任务完成，播放提示音
                    Toolkit.getDefaultToolkit().beep();

                    // 显示通知
                    JOptionPane.showMessageDialog(this,
                            "任务 \"" + task.getName() + "\" 已刷新！",
                            "倒计时结束",
                            JOptionPane.INFORMATION_MESSAGE);

                    updateActiveCount();
                }
            }
        }
    }

    private void updateTableRow(int rowIndex) {
        TimerTask task = timerTasks.get(rowIndex);
        tableModel.setValueAt(task.getName(), rowIndex, 0);
        tableModel.setValueAt(formatTime(task.getTotalSeconds()), rowIndex, 1);
        tableModel.setValueAt(formatTime(task.getRemainingSeconds()), rowIndex, 2);
        tableModel.setValueAt(task.getStatus(), rowIndex, 3);

        // 触发表格重新渲染
        tableModel.fireTableCellUpdated(rowIndex, 3);
    }

    private void updateActiveCount() {
        int activeCount = 0;
        for (TimerTask task : timerTasks) {
            if (task.isRunning()) {
                activeCount++;
            }
        }
        activeLabel.setText("活动任务: " + activeCount + " 个");
    }

    private String formatTime(int totalSeconds) {
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;

        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, seconds);
        } else {
            return String.format("%02d:%02d", minutes, seconds);
        }
    }

    // 自定义表格渲染器，根据状态改变颜色
    class TimerTableCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value,
                    isSelected, hasFocus, row, column);
            if (column == 3) { // 状态列
                String status = (String) value;
                if (status.equals("进行中")) {
                    c.setBackground(new Color(144, 238, 144)); // 浅绿色
                    c.setForeground(Color.BLACK);
                } else if (status.equals("已暂停")) {
                    c.setBackground(new Color(255, 255, 224)); // 浅黄色
                    c.setForeground(Color.BLACK);
                } else if (status.equals("已完成")) {
                    c.setBackground(new Color(255, 182, 193)); // 浅红色
                    c.setForeground(Color.BLACK);
                } else {
                    c.setBackground(Color.WHITE);
                    c.setForeground(Color.BLACK);
                }
            } else if (column == 0) {
                // 任务名称列
                String name = (String) value;
                if (timerTaskNames.contains(name)) {
                    c.setBackground(new Color(255, 192, 203)); // 浅粉色
                }else {
                    c.setBackground(Color.WHITE);
                    c.setForeground(Color.BLACK);
                }
            } else {
                c.setBackground(Color.WHITE);
                c.setForeground(Color.BLACK);
            }

            if (isSelected) {
                c.setBackground(table.getSelectionBackground());
                c.setForeground(table.getSelectionForeground());
            }

            return c;
        }
    }

    // 倒计时任务类
    class TimerTask {
        private String name;
        private String colorMark;
        private int totalSeconds;
        private int remainingSeconds;
        private boolean running;
        private boolean completed;

        public TimerTask(String name, int totalSeconds, String colorMark) {
            this.name = name;
            this.colorMark = colorMark;
            this.totalSeconds = totalSeconds;
            this.remainingSeconds = totalSeconds;
            this.running = false;
            this.completed = false;
        }

        public void start() {
            if (remainingSeconds > 0 && !completed) {
                running = true;
            }
        }

        public void pause() {
            running = false;
        }

        public void reset() {
            remainingSeconds = totalSeconds;
            running = false;
            completed = false;
        }

        public boolean update() {
            if (running && remainingSeconds > 0) {
                remainingSeconds--;
                if (remainingSeconds <= 0) {
                    remainingSeconds = 0;
                    running = false;
                    completed = true;
                    return true; // 返回true表示任务完成
                }
            }
            return false;
        }

        public String getName() {
            return name;
        }

        public int getTotalSeconds() {
            return totalSeconds;
        }

        public int getRemainingSeconds() {
            return remainingSeconds;
        }

        public boolean isRunning() {
            return running;
        }

        public boolean isCompleted() {
            return completed;
        }

        public String getStatus() {
            if (completed) {
                return "已完成";
            } else if (running) {
                return "进行中";
            } else {
                return "已暂停";
            }
        }

        private String getColorMark() {
            return colorMark;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MultiCountdownTimer();
            }
        });
    }
}
